# Fresh Windows PC Setup

This folder includes a self-contained installer (`setup_windows.bat`) designed for a brand-new Windows 10 or Windows 11 PC with no Python or Git pre-installed.

## Option A: Transfer the bundle (Recommended)
1. Copy `opencv-finger-tracking-windows.zip` (or the whole `opencv-finger-tracking` folder) to the Windows PC and extract it.
2. Double-click **`setup_windows.bat`**.
3. Wait for setup to finish, then double-click **`run_windows.bat`**.

## Option B: Single `.bat` file only
1. Copy just **`setup_windows.bat`** into an empty folder on the Windows PC.
2. Double-click **`setup_windows.bat`** — it downloads `main.py`, `requirements.txt`, `hand_landmarker.task`, `uv.exe`, Python 3.12, `opencv-python`, `mediapipe`, and Visual C++ Runtime (if missing), and creates `run_windows.bat`.
3. Double-click **`run_windows.bat`** to start tracking.

## What `setup_windows.bat` downloads and installs
- **Microsoft Visual C++ 2015–2022 Redistributable** (only if `vcruntime140_1.dll` is missing on a fresh Windows install)
- **`uv.exe`** (local portable copy inside `.tools\`)
- **Python 3.12** (managed by `uv`, avoids the Windows Store `python.exe` stub)
- **`opencv-python` & `mediapipe`** into `.venv\`
- **`hand_landmarker.task`** (~7.8 MB MediaPipe hand model)

## Usage tips on Windows
- Double-click **`run_windows.bat`** to launch with your webcam.
- Drag and drop an `.mp4` video or `.jpg`/`.png` image onto **`run_windows.bat`** to test without a camera.
- Press **`q`** or **`Esc`** to quit, or **`s`** to save a snapshot PNG.
