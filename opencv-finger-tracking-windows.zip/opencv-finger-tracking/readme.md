# opencv-fingers

Real-time hand landmark tracking using OpenCV and MediaPipe. Detects up to two hands via webcam and draws a color-coded skeleton overlay with per-finger coloring and live FPS readout.

![Python](https://img.shields.io/badge/python-3.12-blue.svg)
![OpenCV](https://img.shields.io/badge/Open_CV-blue)
![MediaPipe](https://img.shields.io/badge/MediaPipe-orange)
![License](https://img.shields.io/badge/license-MIT-brightgreen)
![Platform](https://img.shields.io/badge/platform-Linux%20%7C%20macOS%20%7C%20Windows-lightgrey)

## Demo

![Hand tracking demo](frame_1781793640992.png)

> Press **q** to quit.

Each finger is rendered in a distinct color:

| Finger | Color   |
|--------|---------|
| Thumb  | Orange  |
| Index  | Green   |
| Middle | Magenta |
| Ring   | Cyan    |
| Pinky  | Yellow  |

## Requirements

- Python 3.10+
- A webcam

## Installation

```bash
git clone https://github.com/your-username/opencv-fingers.git
cd opencv-fingers

python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

pip install -r requirements.txt
```

The MediaPipe hand landmark model (`hand_landmarker.task`, ~12 MB) is downloaded automatically on first run.

## Usage

```bash
python main.py
```

The window title is **Hand Tracking**. FPS is shown in the top-left corner.

## How it works

1. Each webcam frame is flipped horizontally (mirror mode) and converted to RGB.
2. The frame is passed to MediaPipe's `HandLandmarker` in `VIDEO` mode with a monotonic timestamp.
3. For each detected hand, `draw_hand` renders:
   - Colored bone chains from wrist to each fingertip
   - Palm cross-connections in white
   - Highlighted wrist dot and fingertip circles
4. FPS is computed from OpenCV tick counts and overlaid on the frame.

## Configuration

Edit the constants at the top of [main.py](main.py):

| Constant | Default | Description |
|----------|---------|-------------|
| `num_hands` | `2` | Maximum hands to detect |
| `min_hand_detection_confidence` | `0.6` | Detection threshold |
| `min_tracking_confidence` | `0.5` | Tracking threshold |

## License

[MIT](LICENSE)
