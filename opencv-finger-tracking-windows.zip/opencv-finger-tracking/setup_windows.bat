@echo off
setlocal EnableExtensions

set "APP_ROOT=%~dp0"
if "%APP_ROOT:~-1%"=="\" set "APP_ROOT=%APP_ROOT:~0,-1%"
cd /d "%APP_ROOT%"

echo ============================================================
echo  OpenCV Finger Tracking - Fresh Windows PC Setup
echo ============================================================
echo Install folder: %APP_ROOT%
echo.

set "ARCH=%PROCESSOR_ARCHITECTURE%"
if defined PROCESSOR_ARCHITEW6432 set "ARCH=%PROCESSOR_ARCHITEW6432%"
echo Detected Windows architecture: %ARCH%

if /I "%ARCH%"=="ARM64" (
    set "UV_URL=https://github.com/astral-sh/uv/releases/latest/download/uv-aarch64-pc-windows-msvc.zip"
    set "VCREDIST_URL=https://aka.ms/vs/17/release/vc_redist.arm64.exe"
) else (
    set "UV_URL=https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip"
    set "VCREDIST_URL=https://aka.ms/vs/17/release/vc_redist.x64.exe"
)

set "TOOLS_DIR=%APP_ROOT%\.tools"
set "UV_EXE=%TOOLS_DIR%\uv.exe"
set "VENV_DIR=%APP_ROOT%\.venv"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"
set "MODEL_FILE=%APP_ROOT%\hand_landmarker.task"
set "MODEL_URL=https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
set "MAIN_URL=https://raw.githubusercontent.com/khayyam90/opencv-finger-tracking/main/main.py"
set "LICENSE_URL=https://raw.githubusercontent.com/khayyam90/opencv-finger-tracking/main/LICENSE"

echo.
echo [1/6] Checking Microsoft Visual C++ Runtime...
if exist "%SystemRoot%\System32\vcruntime140_1.dll" goto :vcredist_ok
echo vcruntime140_1.dll not found. Downloading Microsoft Visual C++ Redistributable...
set "VCREDIST_EXE=%TEMP%\vc_redist_opencv_setup.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri $env:VCREDIST_URL -OutFile $env:VCREDIST_EXE"
if errorlevel 1 (
    echo [WARN] Could not download Visual C++ Redistributable. Continuing setup...
    goto :vcredist_ok
)
echo Installing Visual C++ Redistributable ^(approve UAC prompt if asked^)...
"%VCREDIST_EXE%" /install /passive /norestart
del /f /q "%VCREDIST_EXE%" >nul 2>&1
:vcredist_ok
echo Visual C++ Runtime check complete.

echo.
echo [2/6] Checking portable uv package manager...
if exist "%UV_EXE%" goto :uv_ok
if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"
set "UV_ZIP=%TEMP%\uv_windows_setup.zip"
echo Downloading uv from %UV_URL%...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri $env:UV_URL -OutFile $env:UV_ZIP; Expand-Archive -Force -Path $env:UV_ZIP -DestinationPath $env:TOOLS_DIR"
if errorlevel 1 goto :fail_download
del /f /q "%UV_ZIP%" >nul 2>&1
if not exist "%UV_EXE%" goto :fail_uv
:uv_ok
echo uv ready: %UV_EXE%

echo.
echo [3/6] Checking project files...
if exist "%APP_ROOT%\main.py" goto :check_license
echo main.py not found locally. Downloading from GitHub...
set "OUT_MAIN=%APP_ROOT%\main.py"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri $env:MAIN_URL -OutFile $env:OUT_MAIN"
if errorlevel 1 goto :fail_download

:check_license
if exist "%APP_ROOT%\LICENSE" goto :check_reqs
set "OUT_LIC=%APP_ROOT%\LICENSE"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri $env:LICENSE_URL -OutFile $env:OUT_LIC" >nul 2>&1

:check_reqs
if exist "%APP_ROOT%\requirements.txt" goto :check_runner
echo Creating requirements.txt...
> "%APP_ROOT%\requirements.txt" echo opencv-python^>=4.8.0
>> "%APP_ROOT%\requirements.txt" echo mediapipe^>=0.10.30,^<1.0

:check_runner
if exist "%APP_ROOT%\run_windows.bat" goto :files_ok
echo Creating run_windows.bat...
> "%APP_ROOT%\run_windows.bat" echo @echo off
>> "%APP_ROOT%\run_windows.bat" echo setlocal EnableExtensions
>> "%APP_ROOT%\run_windows.bat" echo set "APP_ROOT=%%~dp0"
>> "%APP_ROOT%\run_windows.bat" echo if "%%APP_ROOT:~-1%%"=="\" set "APP_ROOT=%%APP_ROOT:~0,-1%%"
>> "%APP_ROOT%\run_windows.bat" echo cd /d "%%APP_ROOT%%"
>> "%APP_ROOT%\run_windows.bat" echo if not exist "%%APP_ROOT%%\.venv\Scripts\python.exe" call "%%APP_ROOT%%\setup_windows.bat" --no-pause
>> "%APP_ROOT%\run_windows.bat" echo if "%%~1"=="" goto :run_cam
>> "%APP_ROOT%\run_windows.bat" echo set "FIRST=%%~1"
>> "%APP_ROOT%\run_windows.bat" echo if "%%FIRST:~0,1%%"=="-" goto :run_args
>> "%APP_ROOT%\run_windows.bat" echo "%%APP_ROOT%%\.venv\Scripts\python.exe" "%%APP_ROOT%%\main.py" --source "%%~1"
>> "%APP_ROOT%\run_windows.bat" echo goto :done
>> "%APP_ROOT%\run_windows.bat" echo :run_cam
>> "%APP_ROOT%\run_windows.bat" echo "%%APP_ROOT%%\.venv\Scripts\python.exe" "%%APP_ROOT%%\main.py"
>> "%APP_ROOT%\run_windows.bat" echo goto :done
>> "%APP_ROOT%\run_windows.bat" echo :run_args
>> "%APP_ROOT%\run_windows.bat" echo "%%APP_ROOT%%\.venv\Scripts\python.exe" "%%APP_ROOT%%\main.py" %%*
>> "%APP_ROOT%\run_windows.bat" echo :done
>> "%APP_ROOT%\run_windows.bat" echo if errorlevel 1 pause

:files_ok
echo Project files ready.

echo.
echo [4/6] Installing Python 3.12 and libraries ^(opencv-python, mediapipe^)...
"%UV_EXE%" python install 3.12
if errorlevel 1 goto :fail_python

"%UV_EXE%" venv "%VENV_DIR%" --python 3.12 --clear
if errorlevel 1 goto :fail_venv

if /I "%ARCH%"=="ARM64" (
    "%UV_EXE%" pip install --python "%VENV_PY%" "opencv-python>=4.8.0" "mediapipe>=0.10.30"
) else (
    "%UV_EXE%" pip install --python "%VENV_PY%" -r "%APP_ROOT%\requirements.txt"
)
if errorlevel 1 goto :fail_pip

echo.
echo [5/6] Downloading MediaPipe hand_landmarker.task model...
if exist "%MODEL_FILE%" goto :model_ok
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri $env:MODEL_URL -OutFile $env:MODEL_FILE"
if errorlevel 1 goto :fail_download
goto :model_done
:model_ok
echo hand_landmarker.task already present.
:model_done

echo.
echo [6/6] Verifying OpenCV + MediaPipe installation...
"%VENV_PY%" -c "import os, cv2, mediapipe as mp; from mediapipe.tasks.python.core.base_options import BaseOptions; from mediapipe.tasks.python.vision import HandLandmarker, HandLandmarkerOptions, RunningMode; opts = HandLandmarkerOptions(base_options=BaseOptions(model_asset_path=os.environ['MODEL_FILE']), running_mode=RunningMode.IMAGE, num_hands=2); d = HandLandmarker.create_from_options(opts); d.close(); print('Verified OK -> OpenCV', cv2.__version__, '| MediaPipe', mp.__version__)"
if errorlevel 1 goto :fail_verify

echo.
echo ============================================================
echo  Setup complete!
echo  Double-click run_windows.bat to start finger tracking.
echo  Press Q in the camera window to quit, or S to save a PNG.
echo ============================================================
if /I "%~1" NEQ "--no-pause" pause
exit /b 0

:fail_download
echo [ERROR] Download failed. Check your internet connection and retry.
goto :fail_end

:fail_uv
echo [ERROR] uv.exe could not be extracted into %TOOLS_DIR%.
goto :fail_end

:fail_python
echo [ERROR] Failed to install Python 3.12 via uv.
goto :fail_end

:fail_venv
echo [ERROR] Failed to create virtual environment in %VENV_DIR%.
goto :fail_end

:fail_pip
echo [ERROR] Failed to install Python packages from PyPI.
goto :fail_end

:fail_verify
echo [ERROR] OpenCV/MediaPipe verification failed.
echo If you see a missing DLL error, install Microsoft Visual C++ 2015-2022 Redistributable:
echo   https://aka.ms/vs/17/release/vc_redist.x64.exe
goto :fail_end

:fail_end
if /I "%~1" NEQ "--no-pause" pause
exit /b 1
