import argparse
import glob
import os
import sys
import time
import urllib.request

import cv2
import mediapipe as mp
from mediapipe.tasks.python.core.base_options import BaseOptions
from mediapipe.tasks.python.vision import (
  HandLandmarker,
  HandLandmarkerOptions,
  RunningMode,
)

MODEL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hand_landmarker.task")
MODEL_URL = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tiff"}

# Landmark indices (MediaPipe hand topology, 0–20)
WRIST = 0
THUMB_CMC, THUMB_MCP, THUMB_IP, THUMB_TIP = 1, 2, 3, 4
INDEX_MCP, INDEX_PIP, INDEX_DIP, INDEX_TIP = 5, 6, 7, 8
MIDDLE_MCP, MIDDLE_PIP, MIDDLE_DIP, MIDDLE_TIP = 9, 10, 11, 12
RING_MCP, RING_PIP, RING_DIP, RING_TIP = 13, 14, 15, 16
PINKY_MCP, PINKY_PIP, PINKY_DIP, PINKY_TIP = 17, 18, 19, 20

FINGER_TIPS = [THUMB_TIP, INDEX_TIP, MIDDLE_TIP, RING_TIP, PINKY_TIP]

FINGER_LANDMARK_GROUPS = [
  [WRIST, THUMB_CMC, THUMB_MCP, THUMB_IP, THUMB_TIP],
  [WRIST, INDEX_MCP, INDEX_PIP, INDEX_DIP, INDEX_TIP],
  [WRIST, MIDDLE_MCP, MIDDLE_PIP, MIDDLE_DIP, MIDDLE_TIP],
  [WRIST, RING_MCP, RING_PIP, RING_DIP, RING_TIP],
  [WRIST, PINKY_MCP, PINKY_PIP, PINKY_DIP, PINKY_TIP],
]

FINGER_COLORS = [
  (0, 140, 255),   # Thumb  — orange
  (0, 220, 0),     # Index  — green
  (220, 0, 220),   # Middle — magenta
  (0, 220, 220),   # Ring   — cyan
  (220, 220, 0),   # Pinky  — yellow
]


def download_model():
  if not os.path.exists(MODEL_PATH):
    print("Downloading hand_landmarker.task model (~12 MB)...")
    urllib.request.urlretrieve(MODEL_URL, MODEL_PATH)
    print("Download complete.")


def landmark_px(landmark, w, h):
  return int(landmark.x * w), int(landmark.y * h)


def draw_hand(frame, hand_landmarks):
  h, w = frame.shape[:2]
  lm = hand_landmarks

  for finger_idx, chain in enumerate(FINGER_LANDMARK_GROUPS):
    color = FINGER_COLORS[finger_idx]
    pts = [landmark_px(lm[i], w, h) for i in chain]
    for a, b in zip(pts, pts[1:]):
      cv2.line(frame, a, b, color, 3, cv2.LINE_AA)
    for pt in pts[1:]:  # skip wrist repetition
      cv2.circle(frame, pt, 5, color, -1, cv2.LINE_AA)

  # Palm cross-connections in white
  for i, j in [(INDEX_MCP, MIDDLE_MCP), (MIDDLE_MCP, RING_MCP), (RING_MCP, PINKY_MCP)]:
    cv2.line(frame, landmark_px(lm[i], w, h), landmark_px(lm[j], w, h), (255, 255, 255), 2, cv2.LINE_AA)

  # Wrist dot
  cv2.circle(frame, landmark_px(lm[WRIST], w, h), 7, (255, 255, 255), -1, cv2.LINE_AA)

  # Fingertip circles
  for tip_id, color in zip(FINGER_TIPS, FINGER_COLORS):
    cv2.circle(frame, landmark_px(lm[tip_id], w, h), 9, color, 2, cv2.LINE_AA)


def parse_args():
  parser = argparse.ArgumentParser(description="Real-time OpenCV + MediaPipe hand/finger tracking")
  parser.add_argument(
    "--source",
    default=None,
    help="Camera index (0), device (/dev/video0), or path to a video/image file. Auto-detects webcam if omitted.",
  )
  parser.add_argument("--hands", type=int, default=2, help="Maximum number of hands to detect (default: 2)")
  parser.add_argument("--det-conf", type=float, default=0.6, help="Min hand detection confidence (default: 0.6)")
  parser.add_argument("--track-conf", type=float, default=0.5, help="Min tracking confidence (default: 0.5)")
  parser.add_argument("--no-flip", action="store_true", help="Disable horizontal mirror flip on webcam feed")
  parser.add_argument("--output", default=None, help="Optional output file path when processing an image or video")
  parser.add_argument("--no-display", action="store_true", help="Run without opening the OpenCV preview window")
  return parser.parse_args()


def open_video_source(source):
  if source is None:
    if sys.platform.startswith("linux"):
      video_nodes = sorted(glob.glob("/dev/video*"))
      if not video_nodes:
        print(
          "Error: No webcam detected (/dev/video* is empty).\n"
          "Plug in a USB webcam and re-run, or pass a fallback video/image with:\n"
          "  python main.py --source path/to/video.mp4",
          file=sys.stderr,
        )
        return None, True
      candidates = [0] + [node for node in video_nodes if node != "/dev/video0"]
    else:
      candidates = [0, 1, 2]

    backends = [cv2.CAP_DSHOW, cv2.CAP_ANY] if sys.platform == "win32" else [cv2.CAP_ANY]
    for backend in backends:
      for candidate in candidates:
        cap = cv2.VideoCapture(candidate, backend)
        if cap.isOpened():
          ok, _ = cap.read()
          if ok:
            return cap, True
        cap.release()

    hint = (
      "Check Windows Privacy Settings -> Camera if using a built-in/USB webcam."
      if sys.platform == "win32"
      else "Checked camera 0 and /dev/video*."
    )
    print(
      f"Error: No webcam detected. {hint}\n"
      "Plug in a webcam and re-run, or pass a fallback video/image with:\n"
      "  python main.py --source path/to/video.mp4",
      file=sys.stderr,
    )
    return None, True

  if source.isdigit():
    cap = cv2.VideoCapture(int(source))
    if not cap.isOpened():
      print(f"Error: Cannot open camera index {source}.", file=sys.stderr)
      return None, True
    return cap, True

  is_stream = source.startswith(("/dev/video", "rtsp://", "http://", "https://"))
  if not is_stream and not os.path.exists(source):
    print(f"Error: Input file not found: {source}", file=sys.stderr)
    return None, False

  cap = cv2.VideoCapture(source)
  if not cap.isOpened():
    print(f"Error: Cannot open video source: {source}", file=sys.stderr)
    return None, is_stream
  return cap, is_stream


def run_image(args):
  if not os.path.exists(args.source):
    print(f"Error: Image file not found: {args.source}", file=sys.stderr)
    return 1

  frame = cv2.imread(args.source)
  if frame is None:
    print(f"Error: Could not decode image: {args.source}", file=sys.stderr)
    return 1

  options = HandLandmarkerOptions(
    base_options=BaseOptions(model_asset_path=MODEL_PATH),
    running_mode=RunningMode.IMAGE,
    num_hands=args.hands,
    min_hand_detection_confidence=args.det_conf,
    min_tracking_confidence=args.track_conf,
  )

  rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
  with HandLandmarker.create_from_options(options) as detector:
    results = detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb))

  hand_count = len(results.hand_landmarks) if results.hand_landmarks else 0
  if results.hand_landmarks:
    for hand_landmarks in results.hand_landmarks:
      draw_hand(frame, hand_landmarks)

  cv2.putText(frame, f"Hands: {hand_count}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2, cv2.LINE_AA)

  if args.output:
    cv2.imwrite(args.output, frame)
    print(f"Saved {args.output} ({hand_count} hand(s) detected)")

  if not args.no_display:
    cv2.imshow("Hand Tracking", frame)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

  return 0


def main():
  args = parse_args()
  download_model()

  if args.source and os.path.splitext(args.source)[1].lower() in IMAGE_EXTS:
    sys.exit(run_image(args))

  cap, is_camera = open_video_source(args.source)
  if cap is None:
    sys.exit(1)

  options = HandLandmarkerOptions(
    base_options=BaseOptions(model_asset_path=MODEL_PATH),
    running_mode=RunningMode.VIDEO,
    num_hands=args.hands,
    min_hand_detection_confidence=args.det_conf,
    min_tracking_confidence=args.track_conf,
  )

  writer = None
  if args.output:
    fps_in = cap.get(cv2.CAP_PROP_FPS)
    if not fps_in or fps_in <= 0:
      fps_in = 30.0
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 640)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 480)
    writer = cv2.VideoWriter(args.output, cv2.VideoWriter_fourcc(*"mp4v"), fps_in, (w, h))

  start_time = time.perf_counter()
  last_timestamp_ms = -1
  prev_tick = cv2.getTickCount()
  flip_feed = is_camera and not args.no_flip

  with HandLandmarker.create_from_options(options) as detector:
    while True:
      ok, frame = cap.read()
      if not ok:
        break

      if flip_feed:
        frame = cv2.flip(frame, 1)
      rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

      timestamp_ms = max(last_timestamp_ms + 1, int((time.perf_counter() - start_time) * 1000))
      last_timestamp_ms = timestamp_ms
      mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
      results = detector.detect_for_video(mp_image, timestamp_ms)

      if results.hand_landmarks:
        for hand_landmarks in results.hand_landmarks:
          draw_hand(frame, hand_landmarks)

      curr_tick = cv2.getTickCount()
      elapsed_ticks = max(1, curr_tick - prev_tick)
      fps = cv2.getTickFrequency() / elapsed_ticks
      prev_tick = curr_tick
      cv2.putText(frame, f"FPS: {fps:.1f}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2, cv2.LINE_AA)

      if writer is not None:
        writer.write(frame)

      if not args.no_display:
        cv2.imshow("Hand Tracking", frame)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q") or key == 27:
          break
        if cv2.getWindowProperty("Hand Tracking", cv2.WND_PROP_VISIBLE) < 1:
          break
        if key == ord("s"):
          filename = f"frame_{int(time.time() * 1000)}.png"
          cv2.imwrite(filename, frame)
          print(f"Saved {filename}")

  cap.release()
  if writer is not None:
    writer.release()
  if not args.no_display:
    cv2.destroyAllWindows()


if __name__ == "__main__":
  main()
