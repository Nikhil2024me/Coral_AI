@echo off
setlocal EnableExtensions

set "APP_ROOT=%~dp0"
if "%APP_ROOT:~-1%"=="\" set "APP_ROOT=%APP_ROOT:~0,-1%"
cd /d "%APP_ROOT%"

if not exist "%APP_ROOT%\.venv\Scripts\python.exe" (
    echo First-time setup needed. Running setup_windows.bat...
    call "%APP_ROOT%\setup_windows.bat" --no-pause
    if errorlevel 1 (
        pause
        exit /b 1
    )
)

if "%~1"=="" goto :run_cam
set "FIRST=%~1"
if "%FIRST:~0,1%"=="-" goto :run_args
"%APP_ROOT%\.venv\Scripts\python.exe" "%APP_ROOT%\main.py" --source "%~1"
goto :done

:run_cam
"%APP_ROOT%\.venv\Scripts\python.exe" "%APP_ROOT%\main.py"
goto :done

:run_args
"%APP_ROOT%\.venv\Scripts\python.exe" "%APP_ROOT%\main.py" %*

:done
if errorlevel 1 pause
